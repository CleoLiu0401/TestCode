<?php
return [
    'apigateway' => '${mc_api_gateway}',
    'apigatewayoutside' => '${mc_api_gateway_outside}',
];