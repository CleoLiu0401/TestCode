#!/bin/bash
source /etc/profile
/var/lib/neo4j/bin/neo4j-admin set-initial-password ${NEO4J_PASSWORD}
/var/lib/neo4j/bin/neo4j start
tail -f /dev/null
